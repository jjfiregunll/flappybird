﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class score : MonoBehaviour {

	
	void Start () {
		
	}

    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.tag == "Player")
        {
            score_sayma.score_art();
        }
    }

        void Update ()
    {
		
	}
}
