﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class score_sayma : MonoBehaviour {

    static int score;
    static int high_score;
    static public int scores;
    static public int high_scores;
    public UnityEngine.UI.Text text;

    void Start()
    {
        score = scores;
        high_score = high_scores;
        score = 0;
        high_score = PlayerPrefs.GetInt("Hscore");
    }

    static public void score_art()
    {
        score++;
        if (score > high_score)
        {
            high_score = score;
        }
    }

    void OnDestroy()
    {
        PlayerPrefs.SetInt("Hscore", high_score);
    }

    void Update()
    {
        text.text = "Skor: " + score.ToString() + "\nYüksek Skor: " + high_score.ToString();
    }
}
