﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class olum : MonoBehaviour {

    public UnityEngine.UI.Text score;
    public UnityEngine.UI.Text hscore;
    void Start () {
       score.text = score_sayma.scores.ToString();
       hscore.text = score_sayma.high_scores.ToString();
    }
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Application.LoadLevel("flapy");
        }
    }
}
