﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camera_sc : MonoBehaviour {

	void Start ()
    {
		
	}

    void FixedUpdate()
    {
        transform.position += new Vector3(bird.forward * Time.deltaTime, 0, 0);
    }

    void Update ()
    {
		
	}

    void OnTriggerEnter2D(Collider2D coll)
    {

        if (coll.transform.tag != "das" && coll.transform.tag != "engel")
        {
            float widht = ((BoxCollider2D)coll).size.x;
            coll.transform.position += new Vector3(widht * 8 - widht / 4, 0, 0);
        }
        else if (coll.transform.tag == "das")
        {
            coll.transform.position += new Vector3(2.5f * 5, 0, 0);
            float newd = Random.Range(-1f, -2.50f);
            coll.transform.position = new Vector3(coll.transform.position.x, newd, coll.transform.position.z);
        }
    }
}


